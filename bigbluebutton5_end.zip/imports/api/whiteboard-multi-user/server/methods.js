import { Meteor } from 'meteor/meteor';
import changeWhiteboardAccess from './methods/changeWhiteboardAccess';

Meteor.methods({
  changeWhiteboardAccess,
});

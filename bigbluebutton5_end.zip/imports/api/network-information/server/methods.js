import { Meteor } from 'meteor/meteor';
import userInstabilityDetected from './methods/userInstabilityDetected';

Meteor.methods({
  userInstabilityDetected,
});

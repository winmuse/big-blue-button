import { Meteor } from 'meteor/meteor';

const PingPong = new Mongo.Collection('ping-pong');

export default PingPong;

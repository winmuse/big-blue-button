import { Meteor } from 'meteor/meteor';
import ping from './methods/ping';

Meteor.methods({
  ping,
});

import { Meteor } from 'meteor/meteor';
import addUserSettings from './methods/addUserSettings';

Meteor.methods({
  addUserSettings,
});

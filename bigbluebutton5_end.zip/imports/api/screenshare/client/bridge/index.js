import KurentoBridge from './kurento';

const screenshareBridge = new KurentoBridge();

export default screenshareBridge;

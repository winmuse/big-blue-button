const MIC_ERROR = {
  NO_SSL: 9,
  MAC_OS_BLOCK: 8,
  NO_PERMISSION: 7,
};

export default { MIC_ERROR };

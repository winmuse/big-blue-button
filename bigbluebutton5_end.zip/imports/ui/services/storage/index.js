import Local from './local';
import Session from './session';

export default {
  Local,
  Session,
};
